# Car-Price-Prediction
Car Price Prediction dataset used along with RFE and KFold for Linear Regression since it is a regression based project.
